"""
Govly Webhook Receiver - FastAPI
--------------------------------
Setup (no secrets committed):
  - Requires Python 3.10+
  - pip install fastapi uvicorn pydantic[dotenv] python-multipart
  - Environment:
      WEBHOOK_SECRET=<set in your environment>
      GOVLY_SOURCE_NAME=govly
      INGEST_SYNC_MODE=sync|async (default: sync)
  - Run (local):
      uvicorn webhook_server:app --host 0.0.0.0 --port 8088
  - Expose:
      Cloudflare Tunnel or ngrok -> set the public URL in Govly's webhook settings.

Notes:
  - Validates HMAC SHA256 signature sent by Govly (header: X-Govly-Signature).
  - Dispatches validated payloads to govly_ingest.process_event().
  - Does not store secrets; reads from environment at runtime.
  - Designed to drop into red-river-sales-automation/modules/govly/.
"""
import hmac, hashlib, json, os
from typing import Dict, Any, Optional
from fastapi import FastAPI, Header, HTTPException, Request
from pydantic import BaseModel

APP_VERSION = "1.0.0"

def _verify_signature(secret: str, body: bytes, signature_header: Optional[str]) -> bool:
    if not signature_header:
        return False
    mac = hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()
    # Expected format: hex digest; allow exact match for simplicity.
    return hmac.compare_digest(mac, signature_header)

class GovlyEvent(BaseModel):
    event_type: str
    timestamp: str
    data: Dict[str, Any]

app = FastAPI(title="Govly Webhook Receiver", version=APP_VERSION)

@app.get("/healthz")
async def healthz():
    return {"ok": True, "version": APP_VERSION}

@app.post("/govly/webhook")
async def govly_webhook(
    request: Request,
    x_govly_signature: Optional[str] = Header(default=None, convert_underscores=False)
):
    secret = os.getenv("WEBHOOK_SECRET")
    if not secret:
        raise HTTPException(status_code=500, detail="WEBHOOK_SECRET not configured")

    raw = await request.body()
    if not _verify_signature(secret, raw, x_govly_signature):
        raise HTTPException(status_code=401, detail="Invalid signature")

    try:
        payload = json.loads(raw.decode("utf-8"))
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON")

    # Basic schema normalization
    event = GovlyEvent(
        event_type=payload.get("event_type", "rfq.created"),
        timestamp=payload.get("timestamp", ""),
        data=payload.get("data", {}),
    )

    # Defer to ingest module
    from govly_ingest import process_event
    mode = os.getenv("INGEST_SYNC_MODE", "sync")
    result = await process_event(event.dict(), mode=mode)
    return {"status": "accepted", "mode": mode, "result": result}
