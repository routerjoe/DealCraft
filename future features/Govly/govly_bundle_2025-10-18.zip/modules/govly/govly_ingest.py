"""
Govly Ingestion & MCP Hand-off
------------------------------
Purpose:
  - Normalize Govly RFQ events into a canonical record.
  - Apply filters (agencies, vehicles, keywords).
  - Upsert into your system of record (e.g., Supabase) and/or dispatch to MCP.

Quick Start:
  - pip install httpx pydantic
  - Environment:
      SUPABASE_URL=<...>            # optional
      SUPABASE_SERVICE_KEY=<...>    # optional (never hard-code)
      MCP_ENDPOINT=http://localhost:xxxx  # if using MCP HTTP tool
      ALLOWED_AGENCIES=AFCENT,AETC,AFTAC,USSF
      ALLOWED_VEHICLES=SEWP,2GIT,CHESS
      KEYWORDS=AFCENT,NetApp,Cisco,Nutanix,Zero Trust,storage,SD-WAN
  - Import path: modules/govly/govly_ingest.py
"""
import os, asyncio
from typing import Dict, Any, List, Tuple
from pydantic import BaseModel, Field

class CanonicalRFQ(BaseModel):
    rfq_id: str = Field(..., description="Govly RFQ identifier")
    title: str
    agency: str = ""
    vehicle: str = ""
    close_date: str = ""
    description: str = ""
    raw: Dict[str, Any] = {}

def _csv_env(name: str) -> List[str]:
    v = os.getenv(name, "")
    return [s.strip() for s in v.split(",") if s.strip()]

def _passes_filters(r: CanonicalRFQ) -> Tuple[bool, str]:
    agencies = set(a.upper() for a in _csv_env("ALLOWED_AGENCIES"))
    vehicles = set(v.upper() for v in _csv_env("ALLOWED_VEHICLES"))
    keywords = set(k.lower() for k in _csv_env("KEYWORDS"))

    if agencies and r.agency.upper() not in agencies:
        return False, f"filtered: agency {r.agency} not in {agencies}"
    if vehicles and r.vehicle.upper() not in vehicles:
        return False, f"filtered: vehicle {r.vehicle} not in {vehicles}"
    if keywords:
        hay = f"{r.title} {r.description}".lower()
        if not any(k in hay for k in keywords):
            return False, "filtered: no keyword match"
    return True, "accepted"

def _canonicalize(event: Dict[str, Any]) -> CanonicalRFQ:
    data = event.get("data", {})
    return CanonicalRFQ(
        rfq_id=str(data.get("id", data.get("rfq_id", ""))),
        title=data.get("title", ""),
        agency=data.get("agency", ""),
        vehicle=data.get("vehicle", ""),
        close_date=data.get("close_date", data.get("due_date", "")),
        description=data.get("description", ""),
        raw=data,
    )

async def _upsert_supabase(r: CanonicalRFQ) -> Dict[str, Any]:
    # Placeholder: implement actual Supabase upsert via REST/RPC if configured
    if not os.getenv("SUPABASE_URL") or not os.getenv("SUPABASE_SERVICE_KEY"):
        return {"skipped": True, "reason": "Supabase not configured"}
    # Intentionally not implemented to avoid leaking secrets in code sample.
    return {"ok": True, "note": "Implement Supabase upsert here"}

async def _dispatch_mcp_task(r: CanonicalRFQ) -> Dict[str, Any]:
    # Placeholder: Create/update Red River Opportunity via MCP
    endpoint = os.getenv("MCP_ENDPOINT")
    if not endpoint:
        return {"skipped": True, "reason": "MCP endpoint not configured"}
    # Intentionally not implemented; depends on your MCP HTTP tool.
    return {"ok": True, "note": "Implement MCP create/update here"}

async def process_event(event: Dict[str, Any], mode: str = "sync") -> Dict[str, Any]:
    r = _canonicalize(event)
    ok, reason = _passes_filters(r)
    if not ok:
        return {"accepted": False, "reason": reason, "rfq_id": r.rfq_id}

    if mode == "sync":
        supabase_res = await _upsert_supabase(r)
        mcp_res = await _dispatch_mcp_task(r)
        return {"accepted": True, "supabase": supabase_res, "mcp": mcp_res, "rfq_id": r.rfq_id}
    else:
        # In real deployments, enqueue to a worker (e.g., Redis, Celery, or n8n webhook)
        asyncio.create_task(_upsert_supabase(r))
        asyncio.create_task(_dispatch_mcp_task(r))
        return {"accepted": True, "queued": True, "rfq_id": r.rfq_id}
