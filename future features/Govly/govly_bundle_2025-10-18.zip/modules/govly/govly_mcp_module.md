    # Govly → MCP Integration Module
    _Prepared for Kilo Code — Saturday, October 18 2025 EDT_

    ## Purpose
    Ingest Govly RFQ webhooks, apply filters for Red River (AFCENT/AETC/USSF, SEWP/2GIT/CHESS, mission keywords), and create/update Opportunities through the MCP server and/or Supabase.

    ## Components
    1. `webhook_server.py` — FastAPI receiver validating HMAC signatures and handing off to ingest.
    2. `govly_ingest.py` — Normalization, filtering, and handoff to MCP/Supabase.
    3. `govly_config.json` — Deploy-time config template (no secrets).
    4. This document (`govly_mcp_module.md`) — Install + Ops guide.

    ## Install
    ```bash
    python -m venv .venv && source .venv/bin/activate
    pip install fastapi uvicorn pydantic[dotenv] python-multipart httpx
    export WEBHOOK_SECRET=replace_me
    export ALLOWED_AGENCIES="AFCENT,AETC,AFTAC,USSF"
    export ALLOWED_VEHICLES="SEWP,2GIT,CHESS"
    export KEYWORDS="AFCENT,NetApp,Cisco,Nutanix,Zero Trust,storage,SD-WAN"
    uvicorn webhook_server:app --host 0.0.0.0 --port 8088
    ```

    Expose the port via Cloudflare Tunnel or ngrok and set the resulting HTTPS URL in Govly's webhook settings:

    - Webhook URL: `https://<public-host>/govly/webhook`
    - Header: `X-Govly-Signature` must be HMAC-SHA256 of raw body using `WEBHOOK_SECRET`.

    ## Testing locally
    ```bash
    BODY='{"event_type":"rfq.created","timestamp":"2025-10-18T12:00:00Z","data":{"id":"361235","title":"AFTAC Enterprise Storage Refresh","agency":"AFTAC","vehicle":"SEWP","close_date":"2025-10-31","description":"NetApp refresh for storage modernization"}}'
    SIG=$(python - <<'PY'
import hmac, hashlib, os
secret=os.environ.get("WEBHOOK_SECRET","replace_me").encode()
body=b'{"event_type":"rfq.created","timestamp":"2025-10-18T12:00:00Z","data":{"id":"361235","title":"AFTAC Enterprise Storage Refresh","agency":"AFTAC","vehicle":"SEWP","close_date":"2025-10-31","description":"NetApp refresh for storage modernization"}}'
print(hmac.new(secret, body, hashlib.sha256).hexdigest())
PY)
    curl -sS -X POST \
  -H "Content-Type: application/json" \
  -H "X-Govly-Signature: $SIG" \
  --data "$BODY" \
  http://localhost:8088/govly/webhook | jq .
    ```

    ## MCP handoff
    - If `MCP_ENDPOINT` is set, `govly_ingest.py` prepares a canonical RFQ and posts a create/update task.
    - If `SUPABASE_URL` + `SUPABASE_SERVICE_KEY` are set, it upserts the record.

    ## Deployment layout
    Place the module under your repo:
    ```text
    red-river-sales-automation/
    └─ modules/
       └─ govly/
          ├─ webhook_server.py
          ├─ govly_ingest.py
          ├─ govly_mcp_module.md
          └─ govly_config.json
    ```

    ## Ops notes
    - Set `INGEST_SYNC_MODE=async` in production to decouple webhook latency.
    - Extend `_dispatch_mcp_task` to hit your MCP HTTP tool or queue (n8n/Redis).
    - Extend `_upsert_supabase` with a secure service role key injected at runtime.

    ## Security
    - Never commit secrets. Use environment variables or your secret manager.
    - Rotate `WEBHOOK_SECRET` if you suspect leakage.
    - Restrict inbound IPs if Govly publishes a source list; otherwise, rely on HMAC.

    ## FAQ — "Radar" integration (from prior chats)
    1. What is Radar? Internal notification feed used to signal downstream events (e.g., "order processed by Red River").
    2. How is it used here? As a separate webhook (e.g., `/radar/webhook`) that triggers an Opportunity status update in MCP after an award/processing event.
    3. Is Radar required for Govly? No. Govly handles RFQ discovery/ingest; Radar is an optional post-award/status automation.
    4. Where would it plug in? Mirror this module: FastAPI endpoint -> validate -> normalize -> MCP update (e.g., set `opportunity.status="Processed"`).
    5. What to build later? Add `radar_listener.py` similarly to `webhook_server.py`, or extend it with an additional route and signature check.

    ## Change log
    - Saturday, October 18 2025 EDT — Initial Kilo Code bundle scaffold.
