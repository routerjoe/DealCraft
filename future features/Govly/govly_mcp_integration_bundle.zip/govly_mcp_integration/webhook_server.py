import os
DATA_DIR = os.getenv("DATA_DIR", "./RedRiver")
PERSIST_DIR = os.getenv("PERSIST_DIR", os.path.join(DATA_DIR, "data"))
QUEUE_DIR = os.path.join(PERSIST_DIR,"webhook_queue")
