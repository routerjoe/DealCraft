from pathlib import Path
BASE = Path(os.getenv("DATA_DIR", "./RedRiver"))
PERSIST = Path(os.getenv("PERSIST_DIR", str(BASE / "data")))
polls = PERSIST / "polls"
queue = PERSIST / "webhook_queue"
