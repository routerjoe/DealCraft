# Placeholder; will be patched.


## Tidy data layout
- `DATA_DIR` → top-level working folder (e.g., `/Users/jonolan/RedRiver`)
- `PERSIST_DIR` → `${DATA_DIR}/data` (polls, webhook_queue, SQLite db)
- Attachments stay in `${DATA_DIR}/attachments`

**.env suggestion**
```
DATA_DIR=/Users/jonolan/RedRiver
PERSIST_DIR=/Users/jonolan/RedRiver/data
RFQ_DB_PATH=/Users/jonolan/RedRiver/data/rfq_tracking.db
```
